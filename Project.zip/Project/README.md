
# 🚢 Titanic Survival Dashboard

This project provides a full analysis of the Titanic dataset using both **Python** and **Power BI** to visualize and understand passenger survival patterns.

---

## 📊 Dashboard Highlights (Power BI)

- **Survival by Passenger Class (Pclass)**
- **Gender-wise Survival (Count & % Breakdown)**
- **Survival Rate by Age Group**
- **Family Size Impact on Survival**
- **Age Distribution of Passengers**
- **Correlation Heatmap**
- **Interactive Slicers** for filtering by AgeGroup, Gender, and Pclass

---

## 🧪 Python Analysis (Optional but included)

The Python script does:
- Data Cleaning (fills missing Age, Embarked)
- Feature Engineering (`FamilySize`, `AgeGroup`)
- Encoding Categorical Columns
- Generates 4 Key Visuals:
  - Correlation Heatmap
  - Survival Rate by Gender
  - Age Distribution
  - Survival by Age Group

Visuals are auto-saved to the `/visuals` folder.

---

## 📁 Folder Structure

```
Titanic-Survival-Analysis/
│
├── data/
│   └── Titanic-Dataset.csv
│
├── visuals/
│   ├── Figure_1.png  ← Survival by Age Group
│   ├── Figure_2.png  ← Age Distribution
│   ├── Figure_3.png  ← Survival Rate by Gender
│   └── Figure_4.png  ← Correlation Heatmap
│
├── notebooks/
│   └── Titanic-Project-Clean.py
│
├── reports/
│   └── Summary_Report.md
│
├── Titanic-Dataset Project.pbix
└── README.md
```

---

## 📦 Dataset Source
[Kaggle Titanic Dataset](https://www.kaggle.com/competitions/titanic/data)

---

## 👨‍💻 Built With

- Python (Pandas, Matplotlib, Seaborn)
- Power BI
- GitHub

---

## 🧠 Key Insights

- **Females** had a much higher survival rate than males
- **1st Class passengers** were more likely to survive
- **Children (0–18)** had better survival chances than elderly
- Family size influenced survival moderately
- `Sex`, `Pclass`, and `Fare` had strongest correlation with survival

---

## 📸 Dashboard Preview

You can find screenshots of the final dashboard in the `/visuals` folder.

---

> This project is a great starter portfolio piece for any aspiring Data Analyst or BI Developer.

