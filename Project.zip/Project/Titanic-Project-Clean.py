
# 🚢 Titanic Dataset Analysis with Python

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset
titanic_data = pd.read_csv("data/Titanic-Dataset.csv")

# Basic overview
print("First 5 rows of the dataset:")
print(titanic_data.head())

print("\nDataset Info:")
print(titanic_data.info())

print("\nMissing values in each column:")
print(titanic_data.isnull().sum())

print("\nStatistical Summary:")
print(titanic_data.describe())

# Data cleaning
titanic_data['Age'] = titanic_data['Age'].fillna(titanic_data['Age'].mean())
titanic_data['Embarked'] = titanic_data['Embarked'].fillna(titanic_data['Embarked'].mode()[0])
titanic_data.drop(['Cabin', 'Name', 'Ticket'], axis=1, inplace=True)

# Encoding categorical columns
titanic_data['Sex'] = titanic_data['Sex'].map({'male': 0, 'female': 1})
titanic_data['Embarked'] = titanic_data['Embarked'].map({'S': 0, 'C': 1, 'Q': 2})

# Feature engineering
titanic_data['FamilySize'] = titanic_data['SibSp'] + titanic_data['Parch']

# Age group bucketing
bins = [0, 18, 30, 40, 50, 60, 100]
labels = ['0-18', '19-30', '31-40', '41-50', '51-60', '60+']
titanic_data['AgeGroup'] = pd.cut(titanic_data['Age'], bins=bins, labels=labels)

# 🔍 Visualizations

# Correlation heatmap
plt.figure(figsize=(10, 6))
sns.heatmap(titanic_data.select_dtypes(include=['int64', 'float64']).corr(), annot=True, cmap="coolwarm")
plt.title("Correlation Heatmap")
plt.tight_layout()
plt.savefig("visuals/Figure_4.png")
plt.close()

# Survival rate by gender
sns.barplot(x='Sex', y='Survived', data=titanic_data)
plt.title("Survival Rate by Gender")
plt.xlabel("Sex (0 = Male, 1 = Female)")
plt.tight_layout()
plt.savefig("visuals/Figure_3.png")
plt.close()

# Age distribution
sns.histplot(titanic_data['Age'], kde=True, bins=30)
plt.title("Age Distribution of Passengers")
plt.xlabel("Age")
plt.tight_layout()
plt.savefig("visuals/Figure_2.png")
plt.close()

# AgeGroup vs Survived
sns.barplot(x='AgeGroup', y='Survived', data=titanic_data)
plt.title("Survival Rate by Age Group")
plt.xlabel("Age Group")
plt.tight_layout()
plt.savefig("visuals/Figure_1.png")
plt.close()

print("\n✅ Analysis complete. Visuals saved to 'visuals/' folder.")
