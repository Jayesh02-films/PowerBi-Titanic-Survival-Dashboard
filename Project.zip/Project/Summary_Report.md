
# 🚢 Titanic Survival Dashboard – Summary Report

This report summarizes key findings from the Titanic dataset, based on the visual analysis performed in Power BI and Python.

---

## 🔍 1. Gender and Survival

From the gender-wise survival breakdown, it’s clear that **females had a much higher survival rate** compared to males.  
This aligns with the "women and children first" policy followed during the evacuation.

- **Female survival rate:** ~74%
- **Male survival rate:** ~19%

This suggests that gender played a significant role in determining survival.

---

## 🔍 2. Age Group Insights

The **0–18 age group** had the **highest survival rate**, while the **60+ group** had the lowest.

- Younger passengers (especially children) were more likely to survive.
- Elderly passengers (60+) had the least chance of survival.

Age clearly influenced survival, especially for minors.

---

## 🔍 3. Class and Fare Influence

The dashboard shows that:
- **1st Class passengers** had the highest survival rates.
- **3rd Class passengers** had the lowest survival rates.
- Passengers who paid **higher fares** were more likely to survive.

This indicates a clear socio-economic divide in survival chances.

---

## 🔍 4. Family Size vs Survival

Passengers traveling with **small families (1–3 members)** had better survival odds.  
Those with very **large families** or **no family** onboard had comparatively lower survival rates.

A moderate family presence may have helped people stay together and navigate evacuation better.

---

## 🔍 5. Age Distribution Overview

Most passengers were between **20–40 years old**.  
The average age hovered around 29–30, which might be influenced by missing values filled using the mean.

---

## 🔍 6. Correlation Analysis

From the correlation heatmap:
- `Sex` and `Pclass` are strongly correlated with survival.
- `Fare` shows a mild positive correlation.
- `Age` and `FamilySize` show relatively low correlations.

This helps highlight which features are more predictive for modeling.

---

## ✅ Final Thoughts

This analysis confirms that **survival on the Titanic was influenced by multiple factors**, including gender, class, age, and family context.  
The dashboard provides an intuitive and data-driven way to understand one of history’s most iconic disasters.
