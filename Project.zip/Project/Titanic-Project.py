import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

titanic_data = pd.read_csv("C:\\Users\\Vimal Agarwal\\OneDrive\\Desktop\\JAYESH\\Data Analyst\\Project\\Titanic-Dataset.csv")
print(titanic_data.head())  # First 5 rows
print(titanic_data.info())  # Column data types
print(titanic_data.describe())  # Statistical summary
print(titanic_data.isnull().sum())  # Missing values in each column
# Fill missing Age values with mean without using inplace
titanic_data['Age'] = titanic_data['Age'].fillna(titanic_data['Age'].mean())
# Fill Embarked with most frequent value (mode)
titanic_data['Embarked'] = titanic_data['Embarked'].fillna(titanic_data['Embarked'].mode()[0])
# Drop Cabin because mostly null
titanic_data = titanic_data.drop(['Cabin', 'Name', 'Ticket'], axis=1)
# Convert 'Sex' column to numeric (male: 0, female: 1)
titanic_data['Sex'] = titanic_data['Sex'].map({'male': 0, 'female': 1})

# Convert 'Embarked' column to numeric (S: 0, C: 1, Q: 2)
titanic_data['Embarked'] = titanic_data['Embarked'].map({'S': 0, 'C': 1, 'Q': 2})
plt.figure(figsize=(10, 6))
sns.heatmap(titanic_data.corr(), annot=True, cmap="coolwarm")
plt.title("Correlation Heatmap")
plt.show()
sns.barplot(x='Sex', y='Survived', data=titanic_data)
plt.show()
sns.histplot(titanic_data['Age'], kde=True)
plt.show()
titanic_data['Sex'] = titanic_data['Sex'].map({'male': 0, 'female': 1})
titanic_data['FamilySize'] = titanic_data['SibSp'] + titanic_data['Parch']
bins = [0, 18, 30, 40, 50, 60, 100]
labels = ['0-18', '19-30', '31-40', '41-50', '51-60', '60+']
titanic_data['AgeGroup'] = pd.cut(titanic_data['Age'], bins=bins, labels=labels)

sns.barplot(x='AgeGroup', y='Survived', data=titanic_data)
plt.show()
